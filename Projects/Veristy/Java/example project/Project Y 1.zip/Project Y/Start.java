import EntityList.*;
import Entity.*;
import File.*;
import GUI.*;
class Start{
	public static void main(String [] args){
	
	LoginPage loginPage = new LoginPage();
}
}

	
		//foodMenu.insert(new Food("ad","ce","de","ae",1));
		//Drinks drinks = new Drinks("a","c","d","a",1,"g");
		//Food foods= drinks;
		//drinks.showFoodInfo();
		//foods.showFoodInfo();
		//foodMenu.showAll();
        //Employee e=new Employee("MC","420","69","Night",5000);
		//e.showEmployeeInfo();
		//EmployeeList emp= new EmployeeList(20);
		//emp.insert(new Employee("ead","ece","dee","ee",666));
		//emp.showAll();
		
		// FoodManagementGUI fmGUI= new FoodManagementGUI();
		//EmployeeManagementGUI emGUI= new EmployeeManagementGUI();
	//HomePageGUI hpGUI= new HomePageGUI();
	//FoodMenu foodMenu = new FoodMenu(200);
	//FFileIO.loadFoodsFromFile(foodMenu);
	//FoodManagementGUI fmGUI= new FoodManagementGUI(foodMenu);